import javax.servlet.*;
import java.io.*;

public class LoginServlet implements Servlet
{		
		ServletConfig config = null;

		public void init(ServletConfig config) throws ServletException
		{
			
			this.config = config;
		}
		
		public void service(ServletRequest request, ServletResponse response) throws ServletException,IOException
		{
			
			
			PrintWriter pw = response.getWriter();
			response.setContentType("text/html");
			
			String name = request.getParameter("uname");
			String password = request.getParameter("pwd");
			
			
			System.out.println(name+" "+password);
			
			
			if(name.equals("pragim") && password.equals("pragim"))
				pw.println("<h2><font color='green'>Login Success</font></h2>");
			else
				pw.println("<h2><font color='red'>Login denied</font></h2>");
				
			
		}
		
		public void destroy(){
			
		}
		
		
		public ServletConfig getServletConfig(){
			
			return config;
		}

		
		public String getServletInfo(){
			
			return "Author : Narendra";
		}


}	